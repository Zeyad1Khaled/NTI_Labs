# Figure and waveform assets

These are supporting images for the college report. The PNG logos retain transparent backgrounds and were cropped only to remove excess transparent canvas; their artwork and colors were not altered.

## Logos for the cover page

- `../logos/cairo-university-logo.png` — Cairo University logo supplied by the user.
- `../logos/nti-logo.png` — National Telecommunication Institute logo supplied by the user.

Use both on the cover, preserve aspect ratio, and place on a light background.

## Final-project ModelSim waveform screenshots

The following JPEG screenshots are extracted from the image objects embedded in `project/docs/Ecu NTI Project report.pdf` in the user-designated repository. They are not newly generated simulations; cite them as screenshots from that report.

| Asset | Source location | Safe description/caption focus |
|---|---|---|
| `parking-assist.jpg` | PDF page 12 (printed page 11) | Echo pulse, green/yellow/red LEDs, and buzzer activity as pulse widths represent different obstacle zones. |
| `drive-mode-controller.jpg` | PDF page 16 (printed page 15) | Throttle/mode inputs, target/current duty, and PWM output during selected mode changes. |
| `smart-rpm-limiter.jpg` | PDF page 18 (printed page 17) | RPM and driving inputs with spark-retard/fuel-cut output changes in the shown testbench sequence. |
| `traction-abs.jpg` | PDF page 21 (printed page 20) | Front/rear wheel-speed inputs, brake/PWM signals, and ABS/TCS indicators in the shown testbench sequence. |

**Do not use the parking screenshot below the Active Spoiler heading on PDF page 8 as a spoiler waveform.** Its signal list is `clk`, `rst`, `echo_pulse`, LEDs, and `buzzer_out`; it is a duplicate/misplaced parking-system screenshot. The correctly placed parking screenshot is page 12. The supplied final-project report has no verified Active Spoiler waveform.

## Other diagrams

These are not waveforms:

- `../figures/proposal-ecu-block-diagram.jpg` — early proposal diagram with four functions. Label as the proposal architecture, not the final five-subsystem code architecture.
- `../figures/fsm-example-state-diagram.jpg` — course FSM example with states `s0`–`s2` and inputs `a`/`b`; do not label it as part of the automotive capstone.
