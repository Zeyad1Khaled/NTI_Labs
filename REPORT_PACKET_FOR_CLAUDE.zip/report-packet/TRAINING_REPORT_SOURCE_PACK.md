# NTI Summer Training Report — Factual Source Pack

**Prepared as source material for a report writer/Claude. This is not the finished college report.** It consolidates the supplied training PDFs, the user-designated GitHub repository, the checked-out `NTI_Labs` lab tree, and the available figures. It is organized in digital-design flow order and separates course theory from code, testbench evidence, and verified results.

> **Accuracy rule:** use this pack as an evidence-based brief, not as permission to invent personal details or results. Bracketed fields and the cautions near the end require confirmation before the report is submitted.

## 1. Source scope and verified context

### Training and institution

- **Training provider:** National Telecommunication Institute (**NTI**).
- **Training/course title shown in the materials:** *Digital Design Using FPGA* / digital design using Verilog and FPGA.
- **Related classroom material:** Introduction to Digital IC Design, RTL Design, and Static Timing Analysis (STA).
- **University logo supplied:** Cairo University. The logo does not identify the faculty or department.
- **Training chronology in the linked repository README:** lab artifacts are labeled from **July 9 through July 22, 2026**; the project announcement sets **Thursday, July 23** as the final-project submission deadline. These are source labels/deadlines, **not proof of the student's exact attendance period**. The final-project README also describes an NTI recognition submission in October 2026, so the sources disagree about the project date; confirm dates rather than copying either label as the student's training period.
- **Exact training start/end dates, student name and ID, faculty/department, personal role, and submission date:** not present in the supplied sources; leave placeholders until supplied by the student.

### User-designated GitHub source

- Repository: <https://github.com/alyhamdy879/FPGA-labs-project>
- Snapshot inspected: `5e8d4893bc48e989762eb57cfb58b80516f282d7` (`main`, committed 2026-10-12).
- This is the requested replacement public repository and the **primary source for the final project**, which is in its `project/` directory.
- The checked-out `NTI_Labs` tree is also inventoried because the original request asked to include its labs and available simulation artifacts. Treat it as supplementary lab evidence; do not silently merge conflicting variants.

### Names appearing in the source material

- The RTL and Digital IC slide decks are credited to **Omar Mostafa Aladawy**.
- July Verilog slides are credited to **Mohammed Salah**.
- STA slides credit **Mohammed Salah** and **Ahmed Abdelazeem**.
- The linked project README lists supervisors as **Eng. Mohammed Salah Aboshosha** and **Eng. Omar Mostafa Aladawy**.
- Group-member names are inconsistent between `pdf/Ecu.pdf` and `project/README.md`; both source lists are recorded in the capstone section. Confirm preferred full spellings before including them in the report.

## 2. Learning path, organized as a digital-design flow

### 2.1 From digital requirements to IC/FPGA context

The lectures explain the progression from a functional requirement to a digital implementation:

1. **Specification:** state the required function, inputs/outputs, clock/reset behavior, performance expectations, and constraints.
2. **Architecture/microarchitecture:** divide the behavior into datapath, storage, and control blocks.
3. **RTL:** describe the hardware in Verilog/SystemVerilog.
4. **Verification:** drive the RTL with testbenches and inspect/check results.
5. **Implementation context:** synthesis maps RTL to logic; FPGA implementation places/routes the design and generates a bitstream, while an ASIC flow continues through physical design and tapeout.

The IC-design lectures provide context on integrated circuits, analog/digital/mixed-signal/RF ICs, SoCs, the semiconductor ecosystem (fabless companies, foundries, IDMs, and EDA vendors), and Moore's Law as a historical/engineering trend in transistor density—not a law that guarantees clock-speed doubling.

**Keep this introductory discussion concise in the report.** The goal is to frame the training, not reproduce the full lecture deck.

### 2.2 Digital logic and number representation — brief foundation

- Digital logic represents information with two logical states, usually written **0** and **1**.
- The core gates are AND, OR, NOT, NAND, NOR, XOR, and XNOR. NAND and NOR are universal; XOR is useful in addition and parity; De Morgan's laws transform between equivalent Boolean forms.
- A half adder combines two one-bit inputs into sum (`A XOR B`) and carry (`A AND B`); a full adder adds a carry-in and can be cascaded.
- Number-system material includes binary/octal/decimal/hexadecimal conversion, binary addition, two's-complement signed values, BCD, and bits/nibbles/bytes/words.

These fundamentals support the later RTL work. A report can cover them in a short subsection rather than repeating individual gate truth tables.

### 2.3 Semiconductor and CMOS concepts

The *Introduction to Digital IC Design* slides bridge logic-level behavior to transistor-level implementation:

- A MOSFET has gate, source, drain, and body/bulk terminals; gate voltage controls conduction through the channel. NMOS is used principally for pull-down behavior and PMOS for pull-up behavior.
- CMOS combines complementary PMOS/NMOS networks. In a static inverter, one device is on and the other off ideally, giving rail-to-rail output and low static power (real devices still have leakage).
- A transmission gate pairs NMOS and PMOS to pass both logic levels. A level-sensitive latch is transparent while enabled; an edge-triggered D flip-flop samples data at a clock edge and holds it between edges.
- The slides introduce voltage-transfer characteristics, logic-level noise margins (`NMH = VOH − VIH`, `NML = VIL − VOL`), fan-in/fan-out, and propagation delay (`tpHL`/`tpLH`).
- Sequential timing concepts include setup/hold, clock-to-Q, recovery/removal for asynchronous reset/set, launch/capture edges, and metastability when timing requirements are violated.

These are **course concepts**; the repository does not contain transistor-level design or a measured CMOS implementation.

### 2.4 Verilog RTL and modeling practice

The RTL lectures and July handouts cover:

- Module definitions, ports (`input`, `output`, `inout`), module hierarchy, instantiation, named versus positional port connections, and parameter/local-parameter use.
- Nets (`wire`/tri-state forms), procedural variables (`reg` in Verilog), packed/unpacked arrays, sized literals, concatenation/replication, and compiler directives.
- Structural, dataflow/continuous-assignment, and behavioral RTL; the same Boolean function can be represented at different abstraction levels.
- `assign` for continuous combinational logic; `always @(*)` for combinational procedural logic; clocked `always @(posedge clk ...)` for sequential logic.
- Blocking assignment (`=`) is the usual choice for ordered combinational procedural logic; nonblocking assignment (`<=`) models edge-triggered state updates. Mixing styles in clocked logic can create simulation-order surprises.
- Complete assignments on all combinational branches and a `default` branch prevent accidental latch inference. `initial` and delay controls are generally testbench constructs, not a substitute for synthesizable hardware reset/timing.
- Functions and tasks: a function returns one value and executes without consuming simulation time; a task can have multiple inputs/outputs and can include waits/delays, so it is commonly used for testbench stimulus. `automatic` tasks give each invocation its own local storage; the default static task shares storage across invocations.
- `casez` treats `Z`/`?` positions as wildcards and retains meaningful `X` matching; `casex` treats X/Z/question-mark positions as wildcards and can mask unknown/uninitialized values. The slides recommend caution with `casex`.
- `generate` blocks elaborate parameterized structures at compile/elaboration time (for example, replicated shift-register or logic stages).

### 2.5 Combinational RTL exercises

The lab set progresses from small selection/operation blocks to reusable components:

- **2-to-1 multiplexer:** selects one of two input words using `sel`; the assignment specifies parameterized width with a default of 5, and the testbench exercises a 5-bit instance. The checked-in snapshots do not share one default (`11_7/multiplexor_.v` has default 6; the cleaned local module requires an override), so the safest factual wording is “parameterized and tested at width 5” unless explicitly describing the assignment specification.
- **Tri-state bus driver:** forwards an 8-bit input while enabled and releases the output to `Z` when disabled. The high-impedance case matters for a shared bus; a testbench must release its own driver while observing the DUT.
- **Parameterized ALU:** 8-bit operands, 3-bit opcode, 8-bit result, and an `a_is_zero` status output. The assignment opcode map is:

  | Opcode | Operation |
  |---|---|
  | `000` | Pass A |
  | `001` | Pass A |
  | `010` | `A + B` |
  | `011` | `A AND B` |
  | `100` | `A XOR B` |
  | `101` | Pass B |
  | `110` | Pass A |
  | `111` | Pass A |

- Other lecture examples include a 2-to-4 decoder, half/full adders, Boolean operators, shifts, comparisons, and muxes written using different RTL styles.

**Important variant warning:** the `serial-datapath` ALU uses a different opcode map (`000` add, `001` subtract, `010` AND, `011` XOR, `100` OR, `101` pass A; disabled/default gives zero). Do not apply the standalone ALU table to the serial datapath.

### 2.6 Sequential blocks, storage, and datapaths

- **D flip-flop/register:** edge-triggered state; register exercises cover reset, load enable, and retaining the prior value when load is inactive. The Lab 7 handout specifies synchronous active-high reset, while the separate `13_7/register .v` implementation uses asynchronous active-high reset. Describe the selected variant explicitly.
- **Counters:** a parameterized 5-bit counter exercise includes reset, load, enable, increment, and hold behavior; load takes priority over enable, and the output holds when both are inactive. Reset style varies by implementation: `14_7/counter.v` uses asynchronous active-high reset, while `14_7/counter_func.v` checks reset synchronously on the rising edge. The separate `Counter_Lab.pdf` specifies a 2-bit counter with asynchronous active-high reset, `up=1` increment, `up=0` decrement, and modulo-4 wraparound; it asks for behavioral, gate-level, and structural versions using a shared testbench plus a waveform screenshot/console log. A function-based counter is also included. The structural/gate-level next-state equations in the local README are `d0 = ~q0` and `d1 = (up & (q1 XOR q0)) OR (~up & ~(q1 XOR q0))`.
- **Memory:** a parameterized single-bidirectional-port RAM uses a 5-bit address and 8-bit data in the lab exercise (32 words). Writes are sampled at a rising clock edge; reads drive the shared data bus while read-enable is active; the two operations should not be requested together for the intended single-port use. Testbench tasks write/read addresses and release the testbench bus driver to `Z` during readback.
- **Shift registers:** PISO (parallel-in/serial-out) and SIPO (serial-in/parallel-out) convert between parallel words and serial transfers.
- **Serial datapath integration:** the local `serial-datapath` project connects a 256 × 20 RAM, a PISO, a SIPO, and an 8-bit ALU. The word fields are bit 19 = ALU enable, bits 18:16 = opcode, bits 15:8 = operand A, bits 7:0 = operand B. The stated example is `3 + 2` using an enabled instruction word. This illustrates the path **RAM → PISO → serial link → SIPO → ALU**.
- **Parity generator:** a serial stream updates an 8-bit sliding window and computes its reduction XOR (`^`) as the parity bit. The codebase includes a function-based implementation and a parameterized/generate implementation; testbench variants send frames serially and compare calculated parity.

### 2.7 Controllers and finite-state machines

- **VeriRISC-style control decoder:** instruction opcode, phase, and the accumulator-zero flag determine bus/register control outputs. The eight instructions are HLT, SKZ, ADD, AND, XOR, LDA, STO, and JMP. The eight externally supplied phases are instruction address, instruction fetch, instruction load, idle, operand address, operand fetch, ALU operation, and store. Control signals include `sel`, `rd`, `ld_ir`, `inc_pc`, `halt`, `ld_ac`, `ld_pc`, `wr`, and `data_e`.
- The checked-in controller module is principally a **combinational opcode/phase decoder**; the phase sequence is supplied externally. Do not claim that this module itself contains an internal phase counter/FSM unless describing a separate implementation.
- FSM concepts include present-state and next-state logic, Moore outputs (state-only) versus Mealy outputs (state plus input), state diagrams/ASM charts, reset behavior, state encoding (binary, one-hot, Gray), and one/two/three-process coding styles.
- The repository has FSM coding-style variants, a rising-edge detector implemented as both Mealy and Moore machines, and overlapping/non-overlapping serial sequence detectors for `110101` (the local `sequence-detector-110101` variants share the matched suffix only in the overlapping version).
- **Debouncer:** a clocked FSM and timer reject rapid mechanical-switch transitions; the output changes only after the input remains stable through the debounce interval.
- A state-diagram image is available at [`assets/figures/fsm-example-state-diagram.jpg`](assets/figures/fsm-example-state-diagram.jpg). Treat it as a course FSM example, not as an ECU-project diagram.

### 2.8 Simulation, testbenches, and verification habits

The training emphasizes simulation as a complement to design, not a substitute for implementation:

- A testbench instantiates the design under test (DUT), drives clock/reset and input stimulus, and observes outputs. Testbenches are simulation-only.
- The material covers directed and randomized stimuli, loops/tasks, `$display`, `$monitor`, `$strobe`, `$dumpfile`/`$dumpvars`, and VCD waveform viewing.
- Self-checking tasks compare actual and expected values (including `X`/`Z` where appropriate) and report failure/pass. Useful examples include mux selection, tri-state disable/enable, ALU opcode/zero-flag checks, register reset/load, controller opcode/phase decoding, and memory write/readback.
- Moore/Mealy edge detectors and switch debouncing use input transitions/glitches as useful stress cases; parity and memory testbenches use loops/tasks to automate repeated vectors.
- The supplied materials and repository READMEs mention ModelSim/Questa, Vivado, Icarus Verilog, and GTKWave; assignment PDFs also show VCS/Xcelium command examples. **List as tools used only those the student actually used.** The available final-project screenshots show the ModelSim waveform UI.

## 3. Lab chronology recorded in the linked repository

This is the repository's artifact chronology, not a confirmed attendance register. It helps connect the flow above to the file tree without repeating the technical explanations.

| Repository date label | Artifact group / main activity |
|---|---|
| July 09, 2026 | RAM/PISO/SIPO/ALU integration (`lab4/`; the local `serial-datapath/` contains a structured equivalent). |
| July 11, 2026 | Multiplexer, tri-state driver, and ALU (`11_7/`). |
| July 12, 2026 | CPU control decode, D flip-flop/shift structure, and register testbench (`12_7/`). |
| July 13, 2026 | `casez`/`casex` comparison and register (`13_7/`). |
| July 14, 2026 | Load/enable counter, function-based counter, and bidirectional RAM (`14_7/`). |
| July 15, 2026 | Task-based memory testbench and parameterized/generate parity (`15_7/`). |
| July 16, 2026 | FSM coding variants and testbench (`16_7/`). |
| July 19, 2026 | Three 2-bit counter modeling styles, rising-edge detectors, sequence detector, and parity verification (`19_7/`). |
| July 20, 2026 | Switch debouncer and testbench (`20_7/`). |
| July 22, 2026 | Timing-path RTL and XDC constraints (`22_7/`). |

## 4. Timing, STA, power, and implementation concepts

### Static Timing Analysis

The STA materials describe STA as constraint-driven, path-based, exhaustive timing analysis that checks timing without applying simulation vectors. It checks timing—not functional correctness. The course covers timing arcs (combinational input-to-output arcs and sequential clock/data constraints), positive/negative/non-unate behavior, launch/capture edges, and start/end points for register-to-register, input-to-register, register-to-output, and input-to-output paths.

- **Arrival time** is when data reaches an endpoint; **required time** comes from clocks and constraints; **slack** is the difference between the allowed/required time and actual arrival (the sign convention depends on whether setup or hold is being reported).
- Setup and hold checks include clock-to-Q, combinational delay, setup/hold time, and clock skew. The slides also discuss recovery/removal for asynchronous controls, false paths, and multi-cycle paths; a multi-cycle setup exception needs a corresponding hold treatment.
- The linked lab's `22_7/timing_paths.v` provides a register-to-register path (`in_data → reg_A → reg_B → out_data`) plus a simple combinational input-to-output path (`in_comb → out_comb`). `timing_paths.xdc` demonstrates a 10 ns clock, 0.5 ns uncertainty, max/min input delays of 2.5/0.5 ns, output delays of 3/1 ns, and max/min combinational delays of 8/2 ns. It defines a virtual clock for the combinational path and illustrates clock/input/output/max/min constraints.
- No STA report, slack result, timing closure, or physical-design result is included in the checked-in lab evidence. Present this as a constraints/STA exercise unless a real report is supplied.

### Power and physical design

The lectures distinguish static/leakage power from dynamic power. A useful first-order dynamic-power relation is `Pdynamic ≈ α · C · V² · f`, where α is switching activity, C is load capacitance, V is supply voltage, and f is switching frequency. They discuss switching, short-circuit, and glitching power; subthreshold, gate-oxide, and junction leakage; and techniques such as clock gating, power gating, multi-threshold cells, and voltage/frequency scaling.

The digital-IC slides describe an ASIC path from specification and microarchitecture through RTL, synthesis, floorplanning, placement, clock-tree synthesis, routing, parasitic extraction/STA, DRC/LVS, tapeout, and fabrication. An FPGA uses configurable logic and routing; the course introduces an RTL-to-bitstream flow. These are **flow concepts**, not evidence that this training produced a fabricated ASIC, measured power data, or a programmed FPGA board.

## 5. Consolidated lab catalog from the checked-out `NTI_Labs` tree

The local repository is organized into self-contained projects. These paths supplement the linked repository's dated folders:

| Local project | What the files demonstrate |
|---|---|
| `multiplexer-2-to-1/` | Combinational, parameterized 2-to-1 selection. |
| `tri-state-driver/` | Shared bus driver with `Z` when disabled. |
| `arithmetic-logic-unit/` | 8-bit ALU, opcode selection, zero detection. |
| `bidirectional-memory/` | 32 × 8 memory on a bidirectional data bus; read/write test. |
| `microcontroller-register/` | Parallel-load register and alternate controller implementation. |
| `microcontroller-controller/` | Eight-instruction/eight-phase control-signal decode. |
| `up-down-counter/` | Same 2-bit counter behavior expressed behaviorally, gate-level, and structurally. |
| `sequence-detector-110101/` | Overlapping and non-overlapping pattern detectors. |
| `stream-parity-generator/` | Serial input, 8-bit shift window, reduction-XOR parity. |
| `serial-datapath/` | Integrated RAM/PISO/SIPO/ALU datapath and a recorded VCD file. |

The two ALU designs have different opcode maps as noted above. The repository documentation also records two subtly different HLT/phase-4 controller behaviors in the alternate control-unit implementations; do not combine their output tables without selecting and naming the implementation.

## 6. Figure and waveform assets supplied with this packet

Assets are stored under `assets/`; captions and source provenance are documented in [`assets/waveforms/README.md`](assets/waveforms/README.md).

### Final-project ModelSim screenshots extracted from the project report

- `assets/waveforms/parking-assist.jpg` — parking echo pulse, LED states, buzzer. Source: `project/docs/Ecu NTI Project report.pdf`, PDF page 12 (printed page 11).
- `assets/waveforms/drive-mode-controller.jpg` — mode/throttle inputs, target/current duty, and PWM. Source: same PDF, page 16 (printed page 15).
- `assets/waveforms/smart-rpm-limiter.jpg` — RPM/speed/brake/throttle inputs and `spark_retard`/`fuel_cut`. Source: same PDF, page 18 (printed page 17).
- `assets/waveforms/traction-abs.jpg` — wheel speeds, brake, PWM, ABS/TCS signals. Source: same PDF, page 21 (printed page 20).
- There is **no verified Active Spoiler waveform** in the supplied report. Its PDF page 8 contains a parking-system trace duplicated from page 12 despite appearing below the spoiler heading; do not caption it as spoiler evidence.

### Other diagrams

- `assets/figures/proposal-ecu-block-diagram.jpg` is the **initial four-function proposal diagram** (parking assist, motor controller, RPM limiter, active aero). It is not the final five-module architecture and must be labeled as a proposal/early design if used.
- `assets/figures/fsm-example-state-diagram.jpg` is a course FSM example (`a`, `b`, states `s0`–`s2`, outputs `y0`/`y1`), not a final-project state diagram.

### Existing local VCD caution

`serial-datapath/sim/top_module_tb.vcd` is present in the checked-out `NTI_Labs` repository, but its header identifies an older testbench named `TOP_MODULE_tb` with a `make_word` function and `NUM_TEST_WORDS` parameter. The current checked-in testbench is named `top_module_tb` and has a different body. Treat the VCD as a **legacy/possibly stale trace**; do not present it as a waveform from the current source snapshot unless it is rerun or independently verified. The four final-project screenshots above are the safer waveform assets for the capstone report.

## 7. Capstone project — make this the final major technical chapter

### 7.1 Identity, purpose, and scope

**Project title in supplied documents:** *Advanced Automotive ECU* / *FPGA-Based Advanced Automotive ECU Suite*.

The project applies digital logic and Verilog RTL to simplified vehicle-control functions. Its intended problem context is simultaneous processing of vehicle inputs such as speed, RPM, throttle, brake state, wheel speed, and ultrasonic echo timing. It aims to demonstrate modular control logic, counters/timers, PWM, sensor-input handling, protection decisions, and simulation of automotive scenarios. The README motivates dedicated hardware by contrasting parallel RTL blocks with sequential software task scheduling; present this as the project's design rationale, not as measured proof of lower latency, jitter, or higher fault tolerance.

The original proposal (`pdf/Ecu.pdf`) describes four functions: parking assist, a motor controller, an RPM limiter, and active aero, with a 200 V motor context. The final code and project report list **five** modules, adding Traction/ABS. The proposal's diagram is available in `assets/figures/proposal-ecu-block-diagram.jpg`; label it as the early proposal rather than the final design.

### 7.2 Architecture and evidence boundary

The five implemented RTL files are separate modules in `project/rtl/`, each with a corresponding testbench in `project/tb/`:

1. Active Spoiler System
2. Advanced Parking System
3. Drive Mode Controller
4. Smart RPM Limiter
5. Traction and ABS System

The project documentation describes a unified/concurrent ECU architecture, and the five blocks are conceptually intended to operate in parallel. **The inspected `project/rtl/` directory contains the five subsystem modules but no top-level integration module.** The project README itself lists top-level integration as a roadmap item. Therefore, the report can discuss the modular ECU concept and the standalone subsystems, but must not claim that a completed integrated top-level ECU was built or deployed unless the student supplies another top-level source file or hardware evidence.

### 7.3 Subsystem specifications and actual RTL behavior

| Subsystem / source files | Inputs and outputs | Behavior encoded in the checked-in RTL |
|---|---|---|
| **Active Spoiler System** — `project/rtl/Active_Spoiler_System.v`; `project/tb/tb_Active_Spoiler_System.v` | Inputs: clock, active-high reset, 9-bit `vehicle_speed`, `brake_pedal`. Outputs: 1-bit `spoiler_pwm`, `airbrake_led`. | Speed thresholds are 80 and 150. Target-angle constants are closed=0, cruise=64, track=128, airbrake=255. If braking and speed > 80, the airbrake target/LED has priority; otherwise >150 selects track, >80 selects cruise, and ≤80 selects closed. `current_angle` moves one count toward `target_angle` when the timer reaches its threshold. An 8-bit counter generates `spoiler_pwm` by comparing the counter with `current_angle`. Testbench cases: (50, no brake), (100, no brake), (160, no brake), (90, brake), (70, brake). |
| **Advanced Parking System** — `project/rtl/Advanced_Parking_System.v`; `project/tb/tb_parking_system.v` | Inputs: clock, active-high reset, ultrasonic `echo_pulse`. Outputs: green/yellow/red LEDs and `buzzer_out`. | A 16-bit counter counts clock cycles while echo is high and classifies the duration when echo falls: `<2000` Danger; `<5000` Close; `<10000` Mid; `≥10000` Far. Far gives no LEDs; Mid green; Close green+yellow; Danger green+yellow+red. The buzzer toggles at zone-dependent counter thresholds 500, 100, and 30 (closer zone = faster toggling). Testbench pulse lengths: 12000, 7000, 3500, and 1000 cycles. These are **clock-count thresholds**, not calibrated distance units. |
| **Drive Mode Controller** — `project/rtl/Drive_Mode_Controller.v`; `project/tb/tb_Drive_Mode_Controller.v` | Inputs: clock, active-high reset, 2-bit `throttle_in`, 2-bit `drive_mode`. Output: 1-bit `motor_pwm`; 8-bit duty values are internal. | Mode/throttle lookup table: Eco (`00`) → 0, 32, 64, 128; Normal (`01`) → 0, 64, 128, 255; Sport (`10`) → 0, 128, 192, 255; Track (`11`) → 0, 192, 255, 255 for throttle `00`, `01`, `10`, `11`. `current_duty` approaches the target by one count per timer interval; an 8-bit counter generates PWM. The checked-in testbench samples several combinations, not every possible 4 × 4 case. |
| **Smart RPM Limiter** — `project/rtl/Smart_RPM_Limiter.v`; `project/tb/tb_Smart_RPM_Limiter.v` | Inputs: clock, active-high reset, 4-bit `engine_rpm`, 9-bit `vehicle_speed`, brake, 2-bit throttle. Outputs: `spark_retard`, `fuel_cut`. | Threshold constants are 4, 9, and 10 in the 4-bit input abstraction; comments/documentation interpret them as approximately 4k/9k/10k RPM. When speed=0, brake=1, and throttle=`11`, launch control asserts spark retard at/above 4 and does not assert fuel cut in that launch branch. Outside that condition, ≥10 asserts fuel cut, ≥9 asserts spark retard, and lower values clear both. Testbench uses selected values (launch: 5,3,8,4; normal: 4,7,9,7,10,3), not a complete 0-to-10,000 sweep. |
| **Traction and ABS System** — `project/rtl/Traction_ABS_System.v`; `project/tb/tb_Traction_ABS_System.v` | Inputs: clock, active-high reset, 8-bit front/rear wheel speeds, brake, 8-bit input PWM. Outputs: 8-bit `final_motor_pwm`, `abs_brake_pulse`, `tcs_active_led`, `abs_active_led`. | `MAX_SLIP=15`. Under braking, `final_motor_pwm` is forced to zero; if front speed exceeds rear by >15, `abs_brake_pulse` toggles and ABS LED is asserted. Otherwise the pulse is set high and the ABS LED is low. Without braking, a rear-over-front difference >15 activates TCS and right-shifts the input PWM by one (approximately half); otherwise PWM passes through. Testbench includes normal travel, wheel-spin, normal braking, ABS-trigger case, then normal travel. This is a simplified digital model, not a full hydraulic ABS algorithm. |

### 7.4 Verification scenarios and waveform interpretation

Each final-project testbench provides a clock/reset and scenario stimuli for its module. The accompanying project PDF includes ModelSim screenshots for Parking, Drive Mode, Smart RPM, and Traction/ABS; the corresponding image assets and page references are above. In the report, explain what each trace shows—for example, echo-duration zones and alert escalation, duty-ramp/PWM behavior, RPM-threshold outputs, or wheel-slip/PWM response.

**Do not overstate the verification:** the checked-in final-project testbenches generally finish with text such as `TEST COMPLETE`; they do not contain comprehensive pass/fail assertions or `$dumpfile`/`$dumpvars` calls. The README's claims of “5/5 testbenches pass,” “self-checking,” and exhaustive sweeps are not established by the inspected testbench source. A screenshot in the report is evidence of a plotted simulation trace, not by itself proof of all behavior. If a strong pass claim is needed, rerun the benches with assertions and retain the simulator log.

### 7.5 Known design limitations worth discussing objectively

These are source-level observations that should be presented neutrally as prototype limitations or future-work items, not hidden:

- The repository snapshot has no top-level ECU wrapper, board pin constraints for this project, or evidence of hardware bring-up; the README lists integration, FPGA bring-up, CAN, and hardware-in-the-loop as roadmap items.
- RPM is a 4-bit abstract value with comments mapping values to thousands of RPM; there is no input sensor scaling/calibration block.
- Parking thresholds are clock counts, not a conversion to physical distance, and the report does not provide sensor calibration.
- The PWM outputs are single-bit signals driven by counters; physical actuator timing, electrical drivers, and calibration are not demonstrated.
- The launch-control branch takes priority over normal hard-cut logic in the current RTL; confirm whether that is intentional before describing engine protection as guaranteed under every operating condition.
- ABS behavior is simplified. It suppresses the PWM command while braking and toggles a signal when a directional wheel-speed difference exceeds a threshold; it is not a complete real-world hydraulic pressure-control cycle.
- No synthesis, resource use, timing closure, measured power, safety validation, or production testing is included in the supplied project evidence.

### 7.6 Team and project metadata to verify

- `pdf/Ecu.pdf` lists: Amr Waheed, Aly Hamdy, Zeyad Khaled, Abdelrahman Mohamed, Adham Amr.
- `project/README.md` lists: Amr Waheed Mohammed, Aly Hamdy Aly, Abdelrahman Youssef, Zeyad Khaled Abd Elhamid, Adham Amr Mohammed.
- These are not identical. Confirm names/spelling and the student's role before including a team list.
- The final-project announcement says groups may have up to five students, asks for a one-page motivation/approach proposal, and gives July 19 proposal discussion and July 23 final submission dates (the repository labels these as 2026).
- `project/Presentation And Demo Video/` contains a YouTube link (`https://youtu.be/cAFjfRypeGs`) and a one-byte/empty PDF named `FPGA_ECU_Presentation .pdf`. The link may be included only if it remains accessible and the team approves; the empty PDF is not usable as presentation evidence.

## 8. Source inventory for citations and cross-checks

### User-provided PDF files

- `Introduction_to_Digital_IC_Design.pdf` — IC history/types, semiconductor and MOSFET basics, CMOS, power, delay, noise margins, ASIC/FPGA flows.
- `RTL_Design_Course.pdf` — logic/number systems, Verilog/RTL styles, combinational and sequential blocks, memories, functions/tasks, FSMs, testbenches, waveform and verification methods.
- `July11_12.pdf` — Verilog types, modules/hierarchy, procedural blocks, event controls, compiler directives, blocking/nonblocking assignments.
- `July13_.pdf` and `July_14_part1.pdf` — `casex`/`casez`, functions, tasks, static/automatic behavior, parity exercise.
- `July_16.pdf` — FSM purpose, Moore/Mealy, diagrams/ASM, coding and state encoding.
- `STA_P1.pdf` and `STA.pdf` — STA basics, timing arcs, sequential timing, path types, slack, exceptions, multi-cycle constraints.
- `Training Report.pdf` — college training-report structure and assessment criteria; use the rubric caveat in the guidelines.

### User-designated public repository

- Root `README.md` — dated progression, lab inventory, testbench claims, capstone overview.
- `11_7/` through `22_7/` — RTL and testbench exercises, including timing paths/XDC.
- `pdf/Semi_Project_Lab 3.pdf` through `pdf/Semi_Project_Lab 9.pdf` — MUX, driver, ALU, controller, register, memory, and counter specifications.
- `pdf/Counter_Lab.pdf` — behavioral/gate-level/structural 2-bit up/down counter learning objectives and requested waveform/log deliverables.
- `pdf/Final_Project_Announcement.pdf` and `pdf/Ecu.pdf` — proposal requirements, initial motivation/architecture.
- `project/rtl/`, `project/tb/`, `project/README.md`, and `project/docs/Ecu NTI Project report.pdf` — final five-module capstone and screenshots.

### Local `NTI_Labs` repository

- Root `README.md` and per-project READMEs; project directories are listed in Section 5.
- `serial-datapath/sim/top_module_tb.vcd` — present, but legacy/stale provenance caveat applies.
- `archives/` contains original RAR copies; the repository README identifies the organized project directories as authoritative sources.

## 9. Student-confirmation items — do not guess

Before a final report is written, obtain/confirm:

1. Student full name, ID, faculty/department, degree/program, and submission date.
2. Exact training start/end dates and whether all repository-labeled lab dates correspond to attended sessions.
3. Official supervisor names/titles and the group roster/name spellings.
4. Which simulators/EDA tools the student actually used, plus versions if known.
5. Whether the five final-project modules were run, whether any testbench assertions/logs exist, and whether the project was ever synthesized/programmed on a board.
6. Whether there is an actual top-level ECU integration or a current Active Spoiler waveform not present in the inspected repository snapshot.
7. Any personal reflection: tasks personally performed, difficulties, teamwork, and suggestions for training improvement.
