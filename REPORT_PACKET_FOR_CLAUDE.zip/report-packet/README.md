# Claude handoff packet

This folder contains source material and report-writing constraints, **not a finished report**.

1. Start with [`TRAINING_REPORT_SOURCE_PACK.md`](TRAINING_REPORT_SOURCE_PACK.md) for the technical facts, lab inventory, capstone detail, sources, and evidence caveats.
2. Follow [`REPORT_GUIDELINES.md`](REPORT_GUIDELINES.md) for report order, cover requirements, figure/citation rules, and a ready-to-use Claude instruction.
3. Attach the `assets/` directory so both cover logos, the proposal/FSM diagrams, and the available final-project waveform screenshots are available to the writer.
4. Replace/resolve every student-specific placeholder using verified details before submission.

The one-file archive `REPORT_PACKET_FOR_CLAUDE.zip` at the repository root contains these two documents and all packet assets for convenient upload.
