# Report-Writing Guidelines for the College Training Report

**Purpose:** this is the style and production brief for the report writer. The factual material belongs in [`TRAINING_REPORT_SOURCE_PACK.md`](TRAINING_REPORT_SOURCE_PACK.md). This file is guidance, not the report itself.

## 1. Required report character

Prepare a formal, technically accurate **summer-training report** about the Digital Design Using FPGA training at the National Telecommunication Institute (NTI). The report should explain both **what the training covered** and **what the student’s lab work demonstrates**. Use the source pack as the factual boundary; do not invent personal, institutional, tool, or results details.

Write in clear professional English unless the college requires Arabic. Keep the narrative original and readable for an engineering-college audience. Explain foundational ideas briefly, then give more space to the implemented labs, verification evidence, timing concepts, and especially the final project.

## 2. Cover page — both logos are required

Use both supplied transparent PNG assets on the cover page:

- Cairo University: [`assets/logos/cairo-university-logo.png`](assets/logos/cairo-university-logo.png)
- National Telecommunication Institute (NTI): [`assets/logos/nti-logo.png`](assets/logos/nti-logo.png)

Place them side by side near the top, with balanced visual size and ample whitespace. Preserve each logo’s aspect ratio; do not stretch, recolor, redraw, or place either one on a dark background that makes its blue lettering hard to read. The Cairo University logo identifies the university only; **do not infer a faculty, department, or program from the logo**.

Suggested cover title:

> **Summer Training Report**  
> **Digital Design Using FPGA**  
> National Telecommunication Institute (NTI)

Include clearly labeled fields for:

- Student’s full name: **[TO BE PROVIDED]**
- Student ID: **[TO BE PROVIDED]**
- Faculty / department / program: **[TO BE CONFIRMED]**
- University: Cairo University
- Training organization: National Telecommunication Institute (NTI)
- Exact training dates: **[TO BE CONFIRMED]**
- Academic supervisor and/or NTI supervisor: **[CONFIRM NAMES AND TITLES]**
- Submission date: **[TO BE PROVIDED]**
- Organization contact details only if required and verified; never fabricate them.

The available materials give July 2026 lab labels and a July 23 project deadline, but they do not establish the student’s exact attendance period. Do not put a guessed date range on the cover.

## 3. Recommended report order

1. **Cover page** with both logos and the required student/training information.
2. **Abstract / executive summary** (about 150–250 words is a useful target, not a stated college limit): purpose, main topics, representative lab work, and the capstone project.
3. **Table of contents**, page numbers, and — if the report includes several figures/tables — lists of figures and tables.
4. **Introduction:** training purpose, objectives, scope, dates once confirmed, and a short map of the report.
5. **Training provider and program context:** a short, sourced description of NTI and the Digital Design Using FPGA program. Do not add unverified organizational history or contact information.
6. **Technical learning, in digital-design flow order:** IC/digital foundations; Verilog RTL; combinational and sequential blocks; datapath and memory; controllers/FSMs; simulation and verification; timing/STA and power/implementation concepts.
7. **Laboratory work and verification evidence:** explain representative designs, the test stimulus, expected/observed behavior, and what the waveforms demonstrate. The source pack already groups overlapping exercises; avoid narrating the same lab once chronologically and again in detail.
8. **Final technical chapter — Advanced Automotive ECU capstone:** place this as the **last major technical chapter**, give it the greatest project-specific detail, and cover its objective, architecture, five subsystems, key logic, testbench scenarios, available waveform evidence, limitations, and future work. Do not imply that the five standalone RTL files are a physically integrated ECU unless the student can provide evidence of a top-level integration.
9. **Conclusion and reflection:** summarize learning and evaluate the experience objectively. Personal strengths, difficulties, teamwork, and improvement points must come from the student, not be invented by the report writer.
10. **References** in one consistent style (IEEE numeric style is suitable if the college has no preferred style).
11. **Appendices:** concise lab/file inventory, selected code excerpts, simulation logs, waveform figures, and supporting material where useful.

The capstone should be the final substantive engineering discussion. A short conclusion, references, and appendices may follow it to retain normal report structure.

## 4. Technical presentation rules

- **Keep elementary gates brief.** One concise paragraph is sufficient: digital logic uses 0/1; AND/OR/NOT and their complements form the basic vocabulary; NAND/NOR are universal; XOR is useful in adders and parity. Do not spend multiple pages repeating truth tables unless the college specifically requires them.
- Explain each concept once, at the point where it first matters. Later lab sections should refer back to it instead of restating the same definition.
- Distinguish combinational logic from clocked storage, and distinguish Verilog simulation constructs from synthesizable RTL.
- Use exact signal names, widths, reset polarity, thresholds, and opcode maps from the selected source. The source pack identifies several variants and discrepancies; do not merge them into one imagined design.
- Separate **course theory**, **implemented RTL**, **simulation stimulus**, and **measured results**. STA and power concepts were studied, but the supplied evidence does not contain a timing report, slack values, power measurements, or a verified board implementation.
- Do not claim that an automotive design is production-ready, safety-certified, physically tested, or suitable for a real vehicle. Describe it as a simplified academic RTL/simulation prototype.
- Do not claim “all tests passed” solely from a README badge or a testbench that only prints “TEST COMPLETE.” Use a pass claim only when supported by actual self-checking assertions or a recorded simulator log.

## 5. Figures and waveforms

Every figure needs a number, a concise caption, and an explanation in the nearby text stating what the reader should notice. Refer to it by number in the body. Use readable resolution, legible signal labels, and visible time scale/units; crop empty margins but do not crop away signal names or axes.

Available final-project waveform screenshots are in [`assets/waveforms/`](assets/waveforms/README.md):

- Parking assist / obstacle zones
- Drive-mode controller / PWM and duty values
- Smart RPM limiter
- Traction control / ABS

These are screenshots reproduced from the supplied project report, not newly run simulations. The supplied final-project report does not contain a reliable Active Spoiler waveform; do not relabel the parking waveform as an Active Spoiler result. If a stronger figure is required, the student should rerun the appropriate testbench and capture the actual signal traces.

Suggested caption pattern:

> **Figure X.** ModelSim waveform for [module], showing [inputs] and [outputs] during [test scenario]. The trace demonstrates [specific visible behavior]. Source: [source report/page or verified simulation log].

Never insert an unexplained screenshot. Do not state numerical measurements from a screenshot unless the values and units are legible and independently supported.

## 6. Sources and citations

Use consistent citations for training slides, lab specifications, repositories, project report, and waveform screenshots. Cite a source near technical claims and include enough information to identify the file. The report should credit the training materials and project/team appropriately; do not present another author’s slide or project wording as original prose.

Primary source identifiers are listed in the source pack. The user-designated repository is:

- <https://github.com/alyhamdy879/FPGA-labs-project>
- Snapshot inspected for this packet: commit `5e8d4893bc48e989762eb57cfb58b80516f282d7` (main, 2026-10-12).

The checked-out `NTI_Labs` workspace is a supplementary lab/code source. Use the linked repository as the requested final-project source, and make clear which repository a cited artifact came from.

The provided `Training Report.pdf` includes a rubric whose listed item values are 5, 5, 22, 5, and 5 marks (sum 42), while its scan appears to mention 44 marks overall. **Do not print a total mark in the report; confirm the current rubric with the college if needed.** The useful rubric criteria are complete cover information; contents/page numbering/summary; scientific content; explanation of every drawing; and professional overall presentation.

## 7. Final quality-control checklist

Before delivery, verify that:

- Both logos appear on the cover and are not distorted.
- Student name, ID, department, dates, supervisors, and any contact details are confirmed rather than guessed.
- The table of contents and all page/figure/table numbers are current.
- Each figure is cited and explained; every waveform is identified as a screenshot or a newly verified simulation.
- The report uses one spelling for NTI, Cairo University, module names, and technical symbols.
- The final project is the last major technical chapter and receives the most focused project coverage.
- The five ECU modules are described according to the code actually present; no unsupported top-level integration, hardware deployment, test pass count, timing closure, or power result is asserted.
- The technical narrative does not repeat the same definitions or lab descriptions in multiple sections.
- All placeholders have been resolved before submission.

## 8. Ready-to-use instruction for Claude

> Use `TRAINING_REPORT_SOURCE_PACK.md` as the factual source and this file as the writing/formatting constraints. Produce a professional college summer-training report, not a raw file summary. Include both supplied logos on the cover page. Organize the technical material in a normal digital-design flow; keep introductory logic-gate material brief; avoid repeating topics. Give the Advanced Automotive ECU capstone the greatest emphasis and make it the last major technical chapter. Use the provided waveform assets only with accurate captions. Preserve all caveats in the source pack, distinguish theory from implemented work, and leave unknown personal details as clearly marked placeholders rather than inventing them. Do not state unsupported test, hardware, STA, or power results.
